# WiFi Sign in page
For the Mikrotik WiFi log-in gatway of National association of Computing Students, Kwara State University chapter.

> Howbeit, anyone is free to use and modify this as they see fit.